# RISC-V Targets

The Target Environment needs setting up to allow the compliance tests to be run on that Target. This can be used while developing compliance test suites or it can be used with new Targets to see if they correctly execute the compliance test suites and are compliant!

This directory provides the necsessary files for the currently available Targets.
